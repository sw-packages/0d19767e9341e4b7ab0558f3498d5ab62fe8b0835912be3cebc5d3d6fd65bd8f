clang-format -style=file -i *.[ch]xx
